var tab = new Array();

tab[0] = 5;
tab[1] = 5;

tab.push(7);
console.log(tab[3]);